# Classroom-and-Course-Management-System
Developed a system for registration, allotment of classrooms for lectures as well as examination allotment for students.
